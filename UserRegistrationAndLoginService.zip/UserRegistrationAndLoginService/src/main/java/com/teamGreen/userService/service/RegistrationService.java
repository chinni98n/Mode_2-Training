package com.teamGreen.userService.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.teamGreen.userService.Dao.RegistrationDAO;
import com.teamGreen.userService.Dto.RegistrationDto;
import com.teamGreen.userService.entity.Registration;

@Service
public class RegistrationService {
	
	@Autowired
	RegistrationDAO registrationDAO;
	
	ModelMapper mapper = new ModelMapper();

	public String registerUser(RegistrationDto registrationDto) {
		Registration registration = mapper.map(registrationDto, Registration.class);
		registrationDAO.save(registration);
		String str="Hi "+registrationDto.getUserName() + "!! You are Successfully Registered. "+"Your User Id id "+registration.getUserId();
		return str;
	}

	public String login(String username, String passwrd) {
		
		Registration login=registrationDAO.findByUserNameAndPasswrd(username, passwrd);
		if(login==null)
			return "enter valid username and password";
		else
			return "You can now search for trains!!!!!" ;

	}
}
