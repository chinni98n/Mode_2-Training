package com.teamGreen.userService.Dto;

import lombok.Data;

@Data
public class RegistrationDto 
{
	String userName;
	String phoneNumber;
	String email;
	String passwrd;
}
