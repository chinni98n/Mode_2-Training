package com.teamGreen.userService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.teamGreen.userService.Dto.RegistrationDto;
import com.teamGreen.userService.service.RegistrationService;

@RestController
@RequestMapping("")
public class RegistrationController 
{
	boolean loggedin = false;
	
	@Autowired
	RegistrationService registrationService;
	
	@PostMapping("/IRCTC/user/register")
	public String registration(@RequestBody RegistrationDto  registrationDto)
	{
		return registrationService.registerUser(registrationDto);
	}
	
	@GetMapping("/IRCTC/user/login")
	public String login(@RequestParam String username, @RequestParam String passwrd){
		String str = registrationService.login(username, passwrd);
		if(!str.equalsIgnoreCase("enter valid username and password"));
			loggedin = true;
		return str;
	}
	
	@GetMapping("/IRCTC/Admin/user/loginVerify")
	private boolean search() {
		if(loggedin)
			return true;
		return false;
	}

}
