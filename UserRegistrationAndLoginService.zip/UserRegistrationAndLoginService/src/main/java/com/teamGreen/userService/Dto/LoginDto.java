package com.teamGreen.userService.Dto;

import lombok.Data;

@Data
public class LoginDto 
{
	String userName;
	String passwrd;
}