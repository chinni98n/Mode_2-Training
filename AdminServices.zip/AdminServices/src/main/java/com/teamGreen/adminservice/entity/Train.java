package com.teamGreen.adminservice.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="train",schema="traindb")
public class Train 
{

	String startTime;
	int seatCount;
	double fare;
	String endTime;
	String trainName;
	
	@Id
	TrainNumberAndDate trainPrimaryKey;
	
	
	
	
	public Train(String startTime, int seatCount, double fare, String endTime, String trainName,
			TrainNumberAndDate trainPrimaryKey) {
		super();
		this.startTime = startTime;
		this.seatCount = seatCount;
		this.fare = fare;
		this.endTime = endTime;
		this.trainName = trainName;
		this.trainPrimaryKey = trainPrimaryKey;
	}




	public Train() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
