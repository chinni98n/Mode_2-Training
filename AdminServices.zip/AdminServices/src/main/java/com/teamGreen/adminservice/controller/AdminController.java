package com.teamGreen.adminservice.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.teamGreen.adminservice.dto.TrainDto;
import com.teamGreen.adminservice.entity.Train;
import com.teamGreen.adminservice.entity.TrainStations;
import com.teamGreen.adminservice.exception.TrainDetailsNotFoundException;
import com.teamGreen.adminservice.exception.TrainNumberNotFoundException;
import com.teamGreen.adminservice.service.AdminServicesImpl;

@RestController
@RequestMapping("/IRCTC/Admin")
public class AdminController {
	
	@Autowired private AdminServicesImpl adminService;
	
	@PostMapping(value = "/addTrains")
	public ResponseEntity<String> addTrains(@RequestBody List<Train> trains) {
			
		boolean isCreateSuccess = adminService.addTrains(trains);
        if (isCreateSuccess) {
            return new ResponseEntity<String>("create success", HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("Already Added", new HttpHeaders(), HttpStatus.NOT_MODIFIED);
        }

	}
	
	@PostMapping(value = "/addTrainStations")
	public ResponseEntity<String> addTrainStations(@RequestBody List<TrainStations> trainStations) {
			
		boolean isCreateSuccess = adminService.addTrainStations(trainStations);
        if (isCreateSuccess) {
            return new ResponseEntity<String>("create success", HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("trainStations already exist", HttpStatus.NOT_IMPLEMENTED);
        }

	}
	
	@GetMapping(value = "/userSearchByTrainNumber")
	public List<TrainDto> userSearchByTrainNumber(@RequestParam Integer trainNumber) {
		List<TrainDto> trainDtoList = adminService.trainSearchByTrainNumber(trainNumber);
		if (trainDtoList.size() == 0) {
			throw new TrainNumberNotFoundException();
		}
		return trainDtoList;

	}

	@GetMapping(value = "/userSearchbyfromtodate")
	public List<TrainDto> userSearchByFromToDate(@RequestParam String source, @RequestParam String destination,
			@RequestParam String date) throws UnsupportedEncodingException {

		System.out.println("/userSearchbyfromtodate");
		source = URLDecoder.decode(source,"UTF-8");
		List<TrainDto> trainDto = adminService.trainSearchByFromToDate(source, destination, date);
		
		if (trainDto == null) {
			throw new TrainDetailsNotFoundException();
		}
		
		return trainDto;
	}
	
	
	@GetMapping(value = "/getTrainDetailsbyTrainNumber")
	public List<Train> getTrainDetails(@RequestParam Integer trainNumber){
		return adminService.getTrainByTrainNumber(trainNumber);
	}

	@GetMapping(value="/getStationByTrainNumber")
	public List<TrainStations> getTrainStations(@RequestParam Integer trainNumber){
		return adminService.getTrainStationByNumber(trainNumber);
	}
	
}
