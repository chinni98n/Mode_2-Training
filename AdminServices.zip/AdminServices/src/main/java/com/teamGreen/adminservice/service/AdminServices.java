package com.teamGreen.adminservice.service;

import java.util.List;

import com.teamGreen.adminservice.dto.TrainDto;
import com.teamGreen.adminservice.entity.Train;
import com.teamGreen.adminservice.entity.TrainStations;

public interface AdminServices {

	boolean addTrains(List<Train> trains);

	boolean addTrainStations(List<TrainStations> trainStations);
	
	public List<Train> getTrainByTrainNumber(Integer trainNumber);
	
	public List<TrainDto> trainSearchByTrainNumber(Integer trainNumber);
	
	public List<TrainDto> trainSearchByFromToDate(String source, String destination, String date);
	
	public List<TrainStations> getTrainStationByNumber(Integer trainNumber);

}