package com.teamGreen.adminservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.teamGreen.adminservice.entity.TrainStations;

@Repository
public interface TrainStationDAO extends CrudRepository<TrainStations, Integer> {

	String sql3 = "select * from trainstations where source=?1 and destination=?2";
	@Query(value=sql3, nativeQuery = true)
	List<TrainStations> getByStations(String source, String destination);
	
	String sql2 = "select * from trainstations where train_number=?1";
	@Query(value = sql2, nativeQuery = true)
	List<TrainStations> getTrainStations(Integer trainNumber);
}