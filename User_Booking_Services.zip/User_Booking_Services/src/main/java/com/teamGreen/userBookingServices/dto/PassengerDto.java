package com.teamGreen.userBookingServices.dto;

import lombok.Data;

@Data
public class PassengerDto {

	String name;
	String age;
	
}
