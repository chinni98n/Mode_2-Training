package com.teamGreen.userBookingServices.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

@RestController
@ControllerAdvice
public class CustomExceptionHandler {
	@ExceptionHandler(TrainNumberNotFoundException.class)
	public final ResponseEntity<Object> handleEntryNotFoundException(TrainNumberNotFoundException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse("Entry Not Found", details);
		return new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(TrainDetailsNotFoundException.class)
	public final ResponseEntity<Object> handleEntryNotFoundException(TrainDetailsNotFoundException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse("Entry Not Found", details);
		return new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(SeatNotAvailableException.class)
	public final ResponseEntity<Object> handleEntryNotFoundException(SeatNotAvailableException ex, WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse("Required number of seats are unavailable!", details);
		return new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(SeatCheckingNotAllowedException.class)
	public final ResponseEntity<Object> handleEntryNotFoundException(SeatCheckingNotAllowedException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse("Please enter required details before enquiring seat availability!",
				details);
		return new ResponseEntity<Object>(error, HttpStatus.FORBIDDEN);
	}
	
	@ExceptionHandler(BookingNotAllowedException.class)
	public final ResponseEntity<Object> handleEntryNotFoundException(BookingNotAllowedException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse("Please login to continue booking!",
				details);
		return new ResponseEntity<Object>(error, HttpStatus.FORBIDDEN);
	}
	
	@ExceptionHandler(CancelNotAllowedException.class)
	public final ResponseEntity<Object> handleEntryNotFoundException(CancelNotAllowedException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse("Cannot cancel ticket!",
				details);
		return new ResponseEntity<Object>(error, HttpStatus.FORBIDDEN);
	}
	
	@ExceptionHandler(InvalidPnrException.class)
	public final ResponseEntity<Object> handleEntryNotFoundException(InvalidPnrException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse("Enter valid PNR",
				details);
		return new ResponseEntity<Object>(error, HttpStatus.FORBIDDEN);
	}
}
