package com.teamGreen.userBookingServices.dao;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.teamGreen.userBookingServices.entity.Booking;

@Repository
public interface BookingDAO extends CrudRepository<Booking, Integer> {

	String sql1=" select * from booking where pnr = ?1";
	
	@Query(value = sql1, nativeQuery = true)
	Booking getBookingDetails(Integer pnr);
	
	@Modifying
	@Query(value="update booking b set b.total_fare= ?1,b.no_of_passengers= ?2 where b.pnr= ?3", nativeQuery=true)
	void updateBookingDetails(double totalFare,int noOfPassenger,Integer pnr);
}
