package com.teamGreen.userBookingServices.entity;

import java.io.Serializable;
import java.time.LocalDate;

import lombok.Data;


@Data
public class TrainNumberandDate implements Serializable
{
	private static final long serialVersionUID = 1L;
	LocalDate date;
	Integer trainNumber;
}
