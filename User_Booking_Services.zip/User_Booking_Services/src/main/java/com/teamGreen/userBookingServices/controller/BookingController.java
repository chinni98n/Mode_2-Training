package com.teamGreen.userBookingServices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.teamGreen.userBookingServices.dto.BookingDto;
import com.teamGreen.userBookingServices.dto.PassengerDto;
import com.teamGreen.userBookingServices.exception.BookingNotAllowedException;
import com.teamGreen.userBookingServices.exception.CancelNotAllowedException;
import com.teamGreen.userBookingServices.exception.SeatCheckingNotAllowedException;
import com.teamGreen.userBookingServices.exception.TrainNumberNotFoundException;
import com.teamGreen.userBookingServices.service.BookingService;
import com.teamGreen.userBookingServices.service.PassengerService;

@RestController
@RequestMapping("/IRCTC/user/booking")
public class BookingController {

	RestTemplate restTemplate = new RestTemplate();

	@Autowired
	BookingService bookingService;

	@Autowired
	PassengerService passengerService;

	boolean bookingStatus = false;
	

	@PostMapping(value = "/ticket", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> bookingDetailsPost(@RequestParam int numberOfPassengers, @RequestParam String date,
			@RequestParam Integer trainNumber) {
		bookingStatus = true;
		Boolean getloginStatus = Boolean.valueOf(restTemplate.getForObject("http://localhost:8080/IRCTC/Admin/user/loginVerify", Boolean.class));
		System.out.println(getloginStatus);
		if (!getloginStatus)
			throw new BookingNotAllowedException("Oops!! Cannot process your request");

		String str = bookingService.bookingDetails(numberOfPassengers, date, trainNumber);
		return new ResponseEntity<>(str, new HttpHeaders(), HttpStatus.OK);
	}

	@RequestMapping(value = "/addpassengerdetails", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public BookingDto passengerDetails(@RequestBody List<PassengerDto> passengerDto, @RequestParam Integer pnr,
			@RequestParam Integer userId) {
		System.out.println(bookingStatus);
		if(bookingStatus) return passengerService.passengerDetails(passengerDto, pnr, userId);
		else throw new TrainNumberNotFoundException("Cannot add passenger");
	}

	@GetMapping(value = "/cancel")
	public String cancelTicket(@RequestParam Integer passengerId) {
		Boolean getloginStatus = Boolean.valueOf(restTemplate.getForObject("http://localhost:8080/IRCTC/Admin/user/loginVerify", Boolean.class));
		if (!getloginStatus) {
			System.out.println("handled");
			throw new CancelNotAllowedException("You must login to continue!!");
		}
		return passengerService.cancelBookedTicket(passengerId);
	}
}

@RequestMapping("/Admin")
class Availability {
	RestTemplate restTemplate = new RestTemplate();
	@Autowired
	BookingService bookingService;
	boolean seatAvailabilityStatus = false;

	@GetMapping(value = "/checkseatavailability", produces = MediaType.APPLICATION_JSON_VALUE)
	public int checkSeatAvailability(@RequestParam String date,
			@RequestParam Integer trainNumber) {
		boolean getloginStatus = Boolean.valueOf(
				restTemplate.getForObject("http://localhost:8080/IRCTC/Admin/user/loginVerify", Boolean.class));

		System.out.println("I am called");
		if (!getloginStatus) {
			throw new SeatCheckingNotAllowedException("Sorry!! unable to process request");
		} // to be checked
		return bookingService.checkSeatAvailability(trainNumber, date);
		
	}
}