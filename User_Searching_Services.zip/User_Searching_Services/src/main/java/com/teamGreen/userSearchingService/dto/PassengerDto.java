package com.teamGreen.userSearchingService.dto;

import lombok.Data;

@Data
public class PassengerDto {

	String name;
	String age;
	Integer tainNumber;
	Integer pnr;
	Integer userId;
	Integer passengerId;
}
