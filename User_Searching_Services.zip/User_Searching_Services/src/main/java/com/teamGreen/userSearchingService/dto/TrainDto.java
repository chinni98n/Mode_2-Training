package com.teamGreen.userSearchingService.dto;
import java.time.LocalDate;

import lombok.Data;

@Data
public class TrainDto 
{
	Integer trainNumber;
	String source;
	String destination;
	String trainName;
	LocalDate date;
	String startTime;
	String endTime;
	double fare;
}
