package com.teamGreen.userSearchingService.service;

import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.teamGreen.userSearchingService.dto.TrainDto;

@Service
public class SearchService {
	
	ModelMapper mapper = new ModelMapper();

	List<TrainDto> trainDto = new ArrayList<TrainDto>();

	@Autowired
	private RestTemplate restTemplate;

	public List<TrainDto> getTrainByTrainNumber(Integer trainNumber) {
		String url = "http://adminservice/IRCTC/Admin/userSearchByTrainNumber";
		String uri = UriComponentsBuilder.fromUriString(url).queryParam("trainNumber", trainNumber).toUriString();
		
	    List<TrainDto> response = restTemplate.exchange(
	    		  uri,
	    		  HttpMethod.GET,
	    		  null,
	    		  new ParameterizedTypeReference<List<TrainDto>>() {}).getBody();
	   
		return response;
	}

	public List<TrainDto> getTrainByFromToDate(String source, String destination, String date) {
		String url = "http://adminservice/IRCTC/Admin/userSearchbyfromtodate";
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url)
		        .queryParam("source", source)
		        .queryParam("destination", destination)
		        .queryParam("date", date);
		List<TrainDto> trains = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, null,  new ParameterizedTypeReference<List<TrainDto>>() {}).getBody();
		return trains;
	}

}
